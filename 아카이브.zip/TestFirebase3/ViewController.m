//
//  ViewController.m
//  TestFirebase3
//
//  Created by apple on 2022/01/16.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
